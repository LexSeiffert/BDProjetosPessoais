--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "trabalhoindividual.";
--
-- Name: trabalhoindividual.; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "trabalhoindividual." WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE "trabalhoindividual." OWNER TO postgres;

\connect "trabalhoindividual."

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: departamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departamento (
    dep_cd_id integer NOT NULL,
    dep_tx_funcao character varying(50),
    dep_tx_descricao character varying(100)
);


ALTER TABLE public.departamento OWNER TO postgres;

--
-- Name: departamento_dep_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.departamento_dep_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departamento_dep_cd_id_seq OWNER TO postgres;

--
-- Name: departamento_dep_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.departamento_dep_cd_id_seq OWNED BY public.departamento.dep_cd_id;


--
-- Name: funcionario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.funcionario (
    fun_cd_id integer NOT NULL,
    fun_tx_nomefun character varying(50),
    fk_dep_cd_id_integer integer
);


ALTER TABLE public.funcionario OWNER TO postgres;

--
-- Name: funcionario_fun_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.funcionario_fun_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.funcionario_fun_cd_id_seq OWNER TO postgres;

--
-- Name: funcionario_fun_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.funcionario_fun_cd_id_seq OWNED BY public.funcionario.fun_cd_id;


--
-- Name: departamento dep_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamento ALTER COLUMN dep_cd_id SET DEFAULT nextval('public.departamento_dep_cd_id_seq'::regclass);


--
-- Name: funcionario fun_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario ALTER COLUMN fun_cd_id SET DEFAULT nextval('public.funcionario_fun_cd_id_seq'::regclass);


--
-- Data for Name: departamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3328.dat

--
-- Data for Name: funcionario; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3330.dat

--
-- Name: departamento_dep_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.departamento_dep_cd_id_seq', 1, false);


--
-- Name: funcionario_fun_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.funcionario_fun_cd_id_seq', 1, false);


--
-- Name: departamento departamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamento
    ADD CONSTRAINT departamento_pkey PRIMARY KEY (dep_cd_id);


--
-- Name: funcionario funcionario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_pkey PRIMARY KEY (fun_cd_id);


--
-- Name: funcionario funcionario_fk_dep_cd_id_integer_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_fk_dep_cd_id_integer_fkey FOREIGN KEY (fk_dep_cd_id_integer) REFERENCES public.departamento(dep_cd_id);


--
-- PostgreSQL database dump complete
--

